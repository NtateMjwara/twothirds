<?php
use app\models\Notification;
use app\models\User;

$unreadCount = !empty($_SESSION['user_id']) ? Notification::unreadCount((int) $_SESSION['user_id']) : 0;
$currentUser = !empty($_SESSION['user_id']) ? User::find((int) $_SESSION['user_id']) : null;
$emailUnverified = $currentUser && empty($currentUser['email_verified_at']);
?>
<?php if ($emailUnverified): ?>
<div class="notice">
    Your email address isn't verified yet.
    <form method="post" action="/resend-verification" style="display:inline;">
        <?= csrf_field() ?>
        <button type="submit" class="link-button">Resend verification email</button>
    </form>
</div>
<?php endif; ?>
<nav class="account-nav">
    <a href="/account/portfolio">Portfolio</a>
    <a href="/account/watchlist">Watchlist</a>
    <a href="/account/profile">Profile</a>
    <a href="/account/address">Address</a>
    <a href="/account/kyc">KYC</a>
    <a href="/account/bank">Bank account</a>
    <a href="/account/notifications">Notifications<?= $unreadCount > 0 ? " ({$unreadCount})" : '' ?></a>
    <a href="/logout">Log out</a>
</nav>
