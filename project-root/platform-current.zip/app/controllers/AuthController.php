<?php
namespace app\controllers;

use app\core\Controller;
use app\models\User;
use app\models\UserProfile;
use app\services\AuthService;
use app\services\RateLimitService;

class AuthController extends Controller
{
    public function showRegister(): void
    {
        $this->render('auth/register');
    }

    public function register(): void
    {
        $this->verifyCsrf();

        $email     = trim($_POST['email'] ?? '');
        $password  = $_POST['password'] ?? '';
        $firstName = trim($_POST['first_name'] ?? '');
        $lastName  = trim($_POST['last_name'] ?? '');
        $phone     = trim($_POST['phone'] ?? '');

        if (User::findByEmail($email)) {
            $this->render('auth/register', ['error' => 'An account with that email already exists.']);
            return;
        }
        if (strlen($password) < 10 || $firstName === '' || $lastName === '') {
            $this->render('auth/register', ['error' => 'Please fill in all fields. Password must be at least 10 characters.']);
            return;
        }

        $userId = AuthService::register($email, $password, $firstName, $lastName, $phone);
        $_SESSION['user_id']   = $userId;
        $_SESSION['user_name'] = $firstName;

        $this->redirect('/account/portfolio');
    }

    public function showLogin(): void
    {
        $this->render('auth/login');
    }

    public function login(): void
    {
        $this->verifyCsrf();

        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $identifier = 'investor:' . strtolower($email);

        if (RateLimitService::isLocked($identifier)) {
            $minutes = RateLimitService::minutesUntilUnlock($identifier);
            $this->render('auth/login', ['error' => "Too many failed attempts. Try again in about {$minutes} minute(s)."]);
            return;
        }

        $user = User::findByEmail($email);

        if (!$user || !password_verify($password, $user['password_hash'])) {
            RateLimitService::recordAttempt($identifier, false);
            $this->render('auth/login', ['error' => 'Incorrect email or password.']);
            return;
        }

        RateLimitService::recordAttempt($identifier, true);
        RateLimitService::clearAttempts($identifier);

        $profile = UserProfile::forUser((int) $user['id']);
        $_SESSION['user_id']   = $user['id'];
        $_SESSION['user_name'] = $profile['first_name'] ?? '';

        $this->redirect('/account/portfolio');
    }

    public function logout(): void
    {
        unset($_SESSION['user_id'], $_SESSION['user_name']);
        $this->redirect('/login');
    }

    public function verifyEmail(string $token): void
    {
        $user = User::findByVerificationToken($token);

        if (!$user) {
            $this->render('auth/verify-email', ['invalid' => true]);
            return;
        }

        User::markEmailVerified((int) $user['id']);
        $this->render('auth/verify-email', ['verified' => true]);
    }

    public function resendVerification(): void
    {
        $this->requireAuth();
        $this->verifyCsrf();

        $userId = (int) $_SESSION['user_id'];
        $user = User::find($userId);

        if ($user && empty($user['email_verified_at'])) {
            $profile = UserProfile::forUser($userId);
            AuthService::sendVerificationEmail($userId, $user['email'], $profile['first_name'] ?? '');
        }

        $this->redirect('/account/portfolio');
    }
}
